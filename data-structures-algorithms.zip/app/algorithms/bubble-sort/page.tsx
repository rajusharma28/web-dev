import type { Metadata } from "next"
import BubbleSortVisualizer from "@/components/visualizers/bubble-sort-visualizer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Bubble Sort - Data Structures & Algorithms",
  description: "Learn about bubble sort with interactive visualizations",
}

export default function BubbleSortPage() {
  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-4xl font-bold mb-6">Bubble Sort</h1>
      <p className="text-xl text-muted-foreground mb-8">
        A simple sorting algorithm that repeatedly steps through the list, compares adjacent elements, and swaps them if
        they are in the wrong order.
      </p>

      <Tabs defaultValue="visualization" className="mb-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="visualization">Visualization</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
        </TabsList>
        <TabsContent value="visualization" className="p-4 border rounded-md mt-2">
          <BubbleSortVisualizer />
        </TabsContent>
        <TabsContent value="implementation" className="p-4 border rounded-md mt-2">
          <Card>
            <CardHeader>
              <CardTitle>JavaScript Implementation</CardTitle>
              <CardDescription>A simple implementation of the bubble sort algorithm in JavaScript.</CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>{`function bubbleSort(arr) {
  const n = arr.length;
  let swapped;
  
  // Clone the array to avoid modifying the original
  const result = [...arr];
  
  do {
    swapped = false;
    
    // Last i elements are already in place
    for (let j = 0; j < n - 1; j++) {
      // Compare adjacent elements
      if (result[j] > result[j + 1]) {
        // Swap them if they are in the wrong order
        [result[j], result[j + 1]] = [result[j + 1], result[j]];
        swapped = true;
      }
    }
  } while (swapped);
  
  return result;
}

// Example usage
const array = [64, 34, 25, 12, 22, 11, 90];
console.log("Original array:", array);
console.log("Sorted array:", bubbleSort(array));

// Time Complexity: O(n²) in worst and average cases
// Space Complexity: O(1) - in-place sorting algorithm
// Best Case: O(n) when array is already sorted`}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">How It Works</h2>
        <ol className="list-decimal pl-6 space-y-2">
          <li>Start at the beginning of the array</li>
          <li>Compare each pair of adjacent elements</li>
          <li>If they are in the wrong order, swap them</li>
          <li>Continue to the end of the array</li>
          <li>If any swaps were made, repeat the process</li>
          <li>If no swaps were made, the array is sorted</li>
        </ol>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Performance Analysis</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Time Complexity</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-6">
                <li>Worst Case: O(n²) - when array is reverse sorted</li>
                <li>Average Case: O(n²)</li>
                <li>Best Case: O(n) - when array is already sorted</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Space Complexity</CardTitle>
            </CardHeader>
            <CardContent>
              <p>O(1) - Bubble sort is an in-place sorting algorithm</p>
              <p className="mt-2">Only requires a constant amount of additional space regardless of input size.</p>
            </CardContent>
          </Card>
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Advantages & Disadvantages</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-bold mb-2">Advantages</h3>
                  <ul className="list-disc pl-6">
                    <li>Simple to understand and implement</li>
                    <li>In-place sorting (no extra space needed)</li>
                    <li>Stable sort (equal elements maintain their order)</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold mb-2">Disadvantages</h3>
                  <ul className="list-disc pl-6">
                    <li>Very inefficient for large datasets</li>
                    <li>Much slower than more advanced algorithms</li>
                    <li>Not suitable for real-world applications with large data</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  )
}

