import type { Metadata } from "next"
import ArrayVisualizer from "@/components/visualizers/array-visualizer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Arrays - Data Structures & Algorithms",
  description: "Learn about arrays with interactive visualizations",
}

export default function ArraysPage() {
  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-4xl font-bold mb-6">Arrays</h1>
      <p className="text-xl text-muted-foreground mb-8">
        An array is a collection of elements stored at contiguous memory locations.
      </p>

      <Tabs defaultValue="visualization" className="mb-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="visualization">Visualization</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
        </TabsList>
        <TabsContent value="visualization" className="p-4 border rounded-md mt-2">
          <ArrayVisualizer />
        </TabsContent>
        <TabsContent value="implementation" className="p-4 border rounded-md mt-2">
          <Card>
            <CardHeader>
              <CardTitle>JavaScript Implementation</CardTitle>
              <CardDescription>
                JavaScript arrays are built-in objects with special properties and methods.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>{`// Creating an array
const arr = [1, 2, 3, 4, 5];

// Accessing elements
console.log(arr[0]); // 1
console.log(arr[2]); // 3

// Adding elements
arr.push(6); // [1, 2, 3, 4, 5, 6]
arr.unshift(0); // [0, 1, 2, 3, 4, 5, 6]

// Removing elements
arr.pop(); // [0, 1, 2, 3, 4, 5]
arr.shift(); // [1, 2, 3, 4, 5]

// Finding elements
const index = arr.indexOf(3); // 2
const includes = arr.includes(5); // true

// Iterating
arr.forEach(item => console.log(item));

// Transforming
const doubled = arr.map(item => item * 2);

// Filtering
const evenNumbers = arr.filter(item => item % 2 === 0);

// Time Complexity
// Access: O(1)
// Search: O(n)
// Insertion/Deletion at end: O(1)
// Insertion/Deletion at beginning: O(n)`}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Key Characteristics</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>Elements are stored in contiguous memory locations</li>
          <li>Each element can be accessed directly using its index</li>
          <li>Fixed size in many languages (but dynamic in JavaScript)</li>
          <li>Homogeneous elements in many languages (but can be mixed in JavaScript)</li>
          <li>Efficient for random access (O(1) time complexity)</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Common Operations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Access</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Time Complexity: O(1)</p>
              <p className="mt-2">Accessing an element at a specific index is very efficient in arrays.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Search</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Time Complexity: O(n)</p>
              <p className="mt-2">Finding an element requires checking each element in the worst case.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Insertion</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Time Complexity: O(n) in worst case</p>
              <p className="mt-2">Adding an element may require shifting existing elements.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Deletion</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Time Complexity: O(n) in worst case</p>
              <p className="mt-2">Removing an element may require shifting subsequent elements.</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  )
}

