import type { Metadata } from "next"
import LinkedListVisualizer from "@/components/visualizers/linked-list-visualizer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Linked Lists - Data Structures & Algorithms",
  description: "Learn about linked lists with interactive visualizations",
}

export default function LinkedListsPage() {
  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-4xl font-bold mb-6">Linked Lists</h1>
      <p className="text-xl text-muted-foreground mb-8">
        A linked list is a linear data structure where elements are not stored at contiguous memory locations.
      </p>

      <Tabs defaultValue="visualization" className="mb-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="visualization">Visualization</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
        </TabsList>
        <TabsContent value="visualization" className="p-4 border rounded-md mt-2">
          <LinkedListVisualizer />
        </TabsContent>
        <TabsContent value="implementation" className="p-4 border rounded-md mt-2">
          <Card>
            <CardHeader>
              <CardTitle>JavaScript Implementation</CardTitle>
              <CardDescription>A simple implementation of a singly linked list in JavaScript.</CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>{`class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
    this.length = 0;
  }

  // Add to end of list
  append(value) {
    const newNode = new Node(value);
    if (!this.head) {
      this.head = newNode;
      this.tail = newNode;
    } else {
      this.tail.next = newNode;
      this.tail = newNode;
    }
    this.length++;
    return this;
  }

  // Add to beginning of list
  prepend(value) {
    const newNode = new Node(value);
    if (!this.head) {
      this.head = newNode;
      this.tail = newNode;
    } else {
      newNode.next = this.head;
      this.head = newNode;
    }
    this.length++;
    return this;
  }

  // Insert at specific position
  insert(index, value) {
    if (index < 0 || index > this.length) {
      return false;
    }
    if (index === 0) {
      return this.prepend(value);
    }
    if (index === this.length) {
      return this.append(value);
    }
    
    const newNode = new Node(value);
    const leader = this.traverseToIndex(index - 1);
    const holdingPointer = leader.next;
    leader.next = newNode;
    newNode.next = holdingPointer;
    this.length++;
    return true;
  }

  // Remove at specific position
  remove(index) {
    if (index < 0 || index >= this.length) {
      return undefined;
    }
    if (index === 0) {
      const removedNode = this.head;
      this.head = this.head.next;
      if (this.length === 1) {
        this.tail = null;
      }
      this.length--;
      return removedNode.value;
    }
    
    const leader = this.traverseToIndex(index - 1);
    const removedNode = leader.next;
    leader.next = removedNode.next;
    if (index === this.length - 1) {
      this.tail = leader;
    }
    this.length--;
    return removedNode.value;
  }

  // Helper method to traverse to index
  traverseToIndex(index) {
    let counter = 0;
    let currentNode = this.head;
    while (counter !== index) {
      currentNode = currentNode.next;
      counter++;
    }
    return currentNode;
  }

  // Print list as array
  toArray() {
    const array = [];
    let currentNode = this.head;
    while (currentNode !== null) {
      array.push(currentNode.value);
      currentNode = currentNode.next;
    }
    return array;
  }
}

// Usage example
const list = new LinkedList();
list.append(10);
list.append(20);
list.prepend(5);
list.insert(2, 15);
console.log(list.toArray()); // [5, 10, 15, 20]
list.remove(1);
console.log(list.toArray()); // [5, 15, 20]

// Time Complexity
// Access: O(n)
// Search: O(n)
// Insertion: O(1) at beginning/end, O(n) at middle
// Deletion: O(1) at beginning, O(n) at middle/end`}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Key Characteristics</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>Elements are stored as separate objects with references to the next element</li>
          <li>Dynamic size - can grow or shrink during execution</li>
          <li>Efficient insertions and deletions (when position is known)</li>
          <li>Inefficient random access - must traverse from beginning</li>
          <li>No need for contiguous memory allocation</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-4">Types of Linked Lists</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Singly Linked List</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Each node contains data and a reference to the next node.</p>
              <p className="mt-2">Traversal is only possible in one direction.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Doubly Linked List</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Each node contains data and references to both next and previous nodes.</p>
              <p className="mt-2">Allows traversal in both directions but uses more memory.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Circular Linked List</CardTitle>
            </CardHeader>
            <CardContent>
              <p>The last node points back to the first node, forming a circle.</p>
              <p className="mt-2">Can be singly or doubly linked.</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  )
}

