import type { Metadata } from "next"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Data Structures & Algorithms Visualizer",
  description: "Interactive visualizations of common data structures and algorithms",
}

const dataStructures = [
  {
    title: "Arrays",
    description: "A collection of elements stored at contiguous memory locations",
    href: "/data-structures/arrays",
  },
  {
    title: "Linked Lists",
    description: "Linear data structure where elements are not stored at contiguous locations",
    href: "/data-structures/linked-lists",
  },
  {
    title: "Stacks",
    description: "LIFO (Last In First Out) data structure",
    href: "/data-structures/stacks",
  },
  {
    title: "Queues",
    description: "FIFO (First In First Out) data structure",
    href: "/data-structures/queues",
  },
  {
    title: "Binary Trees",
    description: "Hierarchical data structure with a root value and two children nodes",
    href: "/data-structures/binary-trees",
  },
  {
    title: "Hash Tables",
    description: "Data structure that implements an associative array",
    href: "/data-structures/hash-tables",
  },
]

const algorithms = [
  {
    title: "Bubble Sort",
    description: "Simple sorting algorithm that repeatedly steps through the list",
    href: "/algorithms/bubble-sort",
  },
  {
    title: "Quick Sort",
    description: "Efficient, divide-and-conquer sorting algorithm",
    href: "/algorithms/quick-sort",
  },
  {
    title: "Merge Sort",
    description: "Divide and conquer sorting algorithm",
    href: "/algorithms/merge-sort",
  },
  {
    title: "Binary Search",
    description: "Search algorithm that finds the position of a target value in a sorted array",
    href: "/algorithms/binary-search",
  },
  {
    title: "Breadth-First Search",
    description: "Algorithm for traversing or searching tree or graph data structures",
    href: "/algorithms/bfs",
  },
  {
    title: "Depth-First Search",
    description: "Algorithm for traversing or searching tree or graph data structures",
    href: "/algorithms/dfs",
  },
]

export default function Home() {
  return (
    <main className="container mx-auto py-10 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Data Structures & Algorithms Visualizer</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Interactive visualizations to help you understand common data structures and algorithms
        </p>
      </div>

      <section className="mb-16">
        <h2 className="text-3xl font-bold mb-6">Data Structures</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dataStructures.map((item) => (
            <Card key={item.title} className="flex flex-col h-full">
              <CardHeader>
                <CardTitle>{item.title}</CardTitle>
                <CardDescription>{item.description}</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto">
                <Link href={item.href} className="w-full">
                  <Button className="w-full">
                    Explore <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-6">Algorithms</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {algorithms.map((item) => (
            <Card key={item.title} className="flex flex-col h-full">
              <CardHeader>
                <CardTitle>{item.title}</CardTitle>
                <CardDescription>{item.description}</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto">
                <Link href={item.href} className="w-full">
                  <Button className="w-full">
                    Explore <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>
    </main>
  )
}

