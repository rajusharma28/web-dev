"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { PlusCircle, MinusCircle, Search, RotateCcw, ArrowRightFromLine, ArrowLeftFromLine } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export default function ArrayVisualizer() {
  const [array, setArray] = useState<number[]>([10, 20, 30, 40, 50])
  const [newValue, setNewValue] = useState<string>("")
  const [searchValue, setSearchValue] = useState<string>("")
  const [searchIndex, setSearchIndex] = useState<number | null>(null)
  const [highlightIndices, setHighlightIndices] = useState<number[]>([])
  const [message, setMessage] = useState<string>("")

  const resetHighlights = () => {
    setHighlightIndices([])
    setSearchIndex(null)
    setMessage("")
  }

  const handleAddToEnd = () => {
    if (!newValue.trim()) {
      toast({
        title: "Error",
        description: "Please enter a value",
        variant: "destructive",
      })
      return
    }

    const value = Number.parseInt(newValue)
    if (isNaN(value)) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive",
      })
      return
    }

    setArray([...array, value])
    setNewValue("")
    setHighlightIndices([array.length])
    setMessage(`Added ${value} at index ${array.length}`)
  }

  const handleAddToStart = () => {
    if (!newValue.trim()) {
      toast({
        title: "Error",
        description: "Please enter a value",
        variant: "destructive",
      })
      return
    }

    const value = Number.parseInt(newValue)
    if (isNaN(value)) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive",
      })
      return
    }

    setArray([value, ...array])
    setNewValue("")
    setHighlightIndices([0])
    setMessage(`Added ${value} at index 0`)
  }

  const handleRemoveFromEnd = () => {
    if (array.length === 0) {
      toast({
        title: "Error",
        description: "Array is empty",
        variant: "destructive",
      })
      return
    }

    const newArray = [...array]
    const removed = newArray.pop()
    setArray(newArray)
    setMessage(`Removed ${removed} from the end`)
  }

  const handleRemoveFromStart = () => {
    if (array.length === 0) {
      toast({
        title: "Error",
        description: "Array is empty",
        variant: "destructive",
      })
      return
    }

    const newArray = [...array]
    const removed = newArray.shift()
    setArray(newArray)
    setMessage(`Removed ${removed} from the start`)
  }

  const handleSearch = () => {
    if (!searchValue.trim()) {
      toast({
        title: "Error",
        description: "Please enter a search value",
        variant: "destructive",
      })
      return
    }

    const value = Number.parseInt(searchValue)
    if (isNaN(value)) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive",
      })
      return
    }

    const index = array.indexOf(value)
    setSearchIndex(index)

    if (index !== -1) {
      setHighlightIndices([index])
      setMessage(`Found ${value} at index ${index}`)
    } else {
      setHighlightIndices([])
      setMessage(`${value} not found in the array`)
    }
  }

  const handleReset = () => {
    setArray([10, 20, 30, 40, 50])
    setNewValue("")
    setSearchValue("")
    resetHighlights()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {array.length === 0 ? (
          <div className="border border-dashed border-gray-300 rounded-md p-4 w-full text-center text-gray-500">
            Empty Array
          </div>
        ) : (
          array.map((value, index) => (
            <div
              key={index}
              className={`flex flex-col items-center ${
                highlightIndices.includes(index)
                  ? "bg-green-100 border-green-500"
                  : searchIndex === -1 && searchValue && Number.parseInt(searchValue) === value
                    ? "bg-red-100 border-red-500"
                    : "bg-white border-gray-300"
              } border rounded-md p-4 min-w-[80px] transition-all duration-300`}
            >
              <div className="text-xs text-gray-500 mb-1">{index}</div>
              <div className="font-bold">{value}</div>
            </div>
          ))
        )}
      </div>

      {message && <div className="bg-blue-50 border border-blue-200 rounded-md p-3 text-blue-800">{message}</div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="newValue">New Value</Label>
            <div className="flex space-x-2">
              <Input
                id="newValue"
                type="number"
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                placeholder="Enter a number"
              />
              <Button onClick={handleAddToEnd} size="icon">
                <PlusCircle className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex space-x-2">
            <Button onClick={handleAddToStart} className="flex-1">
              <ArrowRightFromLine className="mr-2 h-4 w-4" />
              Add to Start
            </Button>
            <Button onClick={handleAddToEnd} className="flex-1">
              Add to End
              <ArrowLeftFromLine className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <div className="flex space-x-2">
            <Button onClick={handleRemoveFromStart} variant="outline" className="flex-1">
              <MinusCircle className="mr-2 h-4 w-4" />
              Remove from Start
            </Button>
            <Button onClick={handleRemoveFromEnd} variant="outline" className="flex-1">
              Remove from End
              <MinusCircle className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="searchValue">Search Value</Label>
            <div className="flex space-x-2">
              <Input
                id="searchValue"
                type="number"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                placeholder="Enter a number to search"
              />
              <Button onClick={handleSearch} size="icon">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Button onClick={handleReset} variant="secondary" className="w-full">
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset Array
          </Button>
        </div>
      </div>

      <div className="bg-muted p-4 rounded-md">
        <h3 className="font-bold mb-2">Array Operations Time Complexity</h3>
        <ul className="space-y-1 text-sm">
          <li>
            <span className="font-medium">Access:</span> O(1) - Constant time to access any element by index
          </li>
          <li>
            <span className="font-medium">Search:</span> O(n) - Linear time to find an element
          </li>
          <li>
            <span className="font-medium">Insertion at end:</span> O(1) - Constant time (amortized)
          </li>
          <li>
            <span className="font-medium">Insertion at beginning:</span> O(n) - Linear time (need to shift elements)
          </li>
          <li>
            <span className="font-medium">Deletion at end:</span> O(1) - Constant time
          </li>
          <li>
            <span className="font-medium">Deletion at beginning:</span> O(n) - Linear time (need to shift elements)
          </li>
        </ul>
      </div>
    </div>
  )
}

