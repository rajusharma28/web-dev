"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Play, Pause, RotateCcw, SkipForward, Shuffle } from "lucide-react"

interface SortingState {
  array: number[]
  currentIndex: number
  nextIndex: number
  sorted: boolean[]
  completed: boolean
}

export default function BubbleSortVisualizer() {
  const [array, setArray] = useState<number[]>([])
  const [originalArray, setOriginalArray] = useState<number[]>([])
  const [currentIndex, setCurrentIndex] = useState<number>(-1)
  const [nextIndex, setNextIndex] = useState<number>(-1)
  const [sorted, setSorted] = useState<boolean[]>([])
  const [isRunning, setIsRunning] = useState<boolean>(false)
  const [speed, setSpeed] = useState<number>(50)
  const [completed, setCompleted] = useState<boolean>(false)
  const [steps, setSteps] = useState<SortingState[]>([])
  const [currentStep, setCurrentStep] = useState<number>(-1)

  const animationRef = useRef<number | null>(null)
  const lastUpdateTimeRef = useRef<number>(0)

  useEffect(() => {
    generateRandomArray()
  }, [])

  const generateRandomArray = () => {
    const size = 10
    const newArray = Array.from({ length: size }, () => Math.floor(Math.random() * 90) + 10)
    setArray([...newArray])
    setOriginalArray([...newArray])
    setSorted(new Array(size).fill(false))
    setCurrentIndex(-1)
    setNextIndex(-1)
    setCompleted(false)
    setIsRunning(false)
    setCurrentStep(-1)
    setSteps([])
  }

  const resetArray = () => {
    setArray([...originalArray])
    setSorted(new Array(originalArray.length).fill(false))
    setCurrentIndex(-1)
    setNextIndex(-1)
    setCompleted(false)
    setIsRunning(false)
    setCurrentStep(-1)
  }

  const generateSortingSteps = () => {
    const steps: SortingState[] = []
    const arr = [...originalArray]
    const n = arr.length
    const sortedIndices = new Array(n).fill(false)

    // Initial state
    steps.push({
      array: [...arr],
      currentIndex: -1,
      nextIndex: -1,
      sorted: [...sortedIndices],
      completed: false,
    })

    let swapped

    do {
      swapped = false

      for (let i = 0; i < n - 1; i++) {
        // Comparing state
        steps.push({
          array: [...arr],
          currentIndex: i,
          nextIndex: i + 1,
          sorted: [...sortedIndices],
          completed: false,
        })

        if (arr[i] > arr[i + 1]) {
          // Swap
          ;[arr[i], arr[i + 1]] = [arr[i + 1], arr[i]]
          swapped = true

          // After swap state
          steps.push({
            array: [...arr],
            currentIndex: i,
            nextIndex: i + 1,
            sorted: [...sortedIndices],
            completed: false,
          })
        }
      }

      // Mark the last element as sorted
      sortedIndices[n - 1 - (steps.length > 1 ? Math.floor((steps.length - 1) / (2 * n)) : 0)] = true

      steps.push({
        array: [...arr],
        currentIndex: -1,
        nextIndex: -1,
        sorted: [...sortedIndices],
        completed: false,
      })
    } while (swapped)

    // Final state - all sorted
    steps.push({
      array: [...arr],
      currentIndex: -1,
      nextIndex: -1,
      sorted: new Array(n).fill(true),
      completed: true,
    })

    return steps
  }

  const startSorting = () => {
    if (completed) {
      resetArray()
    }

    if (steps.length === 0) {
      const sortingSteps = generateSortingSteps()
      setSteps(sortingSteps)
    }

    setIsRunning(true)

    if (currentStep === -1) {
      setCurrentStep(0)
    }
  }

  const pauseSorting = () => {
    setIsRunning(false)
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
  }

  const stepForward = () => {
    if (currentStep < steps.length - 1) {
      const nextStep = currentStep + 1
      setCurrentStep(nextStep)
      applyStep(nextStep)
    }
  }

  const applyStep = (stepIndex: number) => {
    if (stepIndex >= 0 && stepIndex < steps.length) {
      const step = steps[stepIndex]
      setArray([...step.array])
      setCurrentIndex(step.currentIndex)
      setNextIndex(step.nextIndex)
      setSorted([...step.sorted])
      setCompleted(step.completed)
    }
  }

  useEffect(() => {
    if (isRunning && steps.length > 0) {
      const animate = (timestamp: number) => {
        if (!lastUpdateTimeRef.current) {
          lastUpdateTimeRef.current = timestamp
        }

        const elapsed = timestamp - lastUpdateTimeRef.current
        const delay = 1000 - speed * 9 // Map 1-100 to 900-0ms

        if (elapsed > delay) {
          if (currentStep < steps.length - 1) {
            const nextStep = currentStep + 1
            setCurrentStep(nextStep)
            applyStep(nextStep)
            lastUpdateTimeRef.current = timestamp
          } else {
            setIsRunning(false)
            return
          }
        }

        animationRef.current = requestAnimationFrame(animate)
      }

      animationRef.current = requestAnimationFrame(animate)

      return () => {
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current)
        }
      }
    }
  }, [isRunning, currentStep, steps, speed])

  const getBarColor = (index: number) => {
    if (sorted[index]) return "bg-green-500"
    if (index === currentIndex) return "bg-blue-500"
    if (index === nextIndex) return "bg-purple-500"
    return "bg-gray-300"
  }

  return (
    <div className="space-y-6">
      <div className="h-64 flex items-end justify-center space-x-2 border rounded-md p-4 bg-white">
        {array.map((value, index) => (
          <div key={index} className="flex flex-col items-center">
            <div
              className={`w-8 ${getBarColor(index)} transition-all duration-300 rounded-t-md`}
              style={{ height: `${value * 2}px` }}
            ></div>
            <div className="text-xs mt-1">{value}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={isRunning ? pauseSorting : startSorting} className="flex-1">
          {isRunning ? (
            <>
              <Pause className="mr-2 h-4 w-4" />
              Pause
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" />
              {completed || currentStep > 0 ? "Continue" : "Start"}
            </>
          )}
        </Button>
        <Button
          onClick={stepForward}
          variant="outline"
          disabled={isRunning || currentStep >= steps.length - 1}
          className="flex-1"
        >
          <SkipForward className="mr-2 h-4 w-4" />
          Step
        </Button>
        <Button onClick={resetArray} variant="outline" disabled={isRunning && !completed} className="flex-1">
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
        <Button onClick={generateRandomArray} variant="outline" disabled={isRunning} className="flex-1">
          <Shuffle className="mr-2 h-4 w-4" />
          New Array
        </Button>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between">
          <Label htmlFor="speed">Animation Speed</Label>
          <span className="text-sm text-muted-foreground">{speed}%</span>
        </div>
        <Slider id="speed" min={1} max={100} step={1} value={[speed]} onValueChange={(value) => setSpeed(value[0])} />
      </div>

      <div className="bg-muted p-4 rounded-md">
        <h3 className="font-bold mb-2">Current Status</h3>
        <div className="text-sm">
          {completed ? (
            <p className="text-green-600">Sorting completed!</p>
          ) : currentStep === -1 ? (
            <p>Press Start to begin sorting</p>
          ) : currentIndex !== -1 && nextIndex !== -1 ? (
            <p>
              Comparing elements at positions {currentIndex} ({array[currentIndex]}) and {nextIndex} ({array[nextIndex]}
              )
            </p>
          ) : (
            <p>Preparing next pass...</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-blue-500 rounded-sm"></div>
          <span className="text-sm">Current element</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-purple-500 rounded-sm"></div>
          <span className="text-sm">Next element</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-green-500 rounded-sm"></div>
          <span className="text-sm">Sorted element</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-gray-300 rounded-sm"></div>
          <span className="text-sm">Unsorted element</span>
        </div>
      </div>
    </div>
  )
}

