"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { PlusCircle, MinusCircle, Search, RotateCcw, ArrowRightFromLine, ArrowLeftFromLine } from "lucide-react"
import { toast } from "@/hooks/use-toast"

class Node {
  value: number
  next: Node | null

  constructor(value: number) {
    this.value = value
    this.next = null
  }
}

class LinkedList {
  head: Node | null
  tail: Node | null
  length: number

  constructor() {
    this.head = null
    this.tail = null
    this.length = 0
  }

  append(value: number) {
    const newNode = new Node(value)
    if (!this.head) {
      this.head = newNode
      this.tail = newNode
    } else {
      if (this.tail) {
        this.tail.next = newNode
        this.tail = newNode
      }
    }
    this.length++
    return this
  }

  prepend(value: number) {
    const newNode = new Node(value)
    if (!this.head) {
      this.head = newNode
      this.tail = newNode
    } else {
      newNode.next = this.head
      this.head = newNode
    }
    this.length++
    return this
  }

  removeFromFront() {
    if (!this.head) return null

    const removedNode = this.head
    this.head = this.head.next

    if (!this.head) {
      this.tail = null
    }

    this.length--
    return removedNode.value
  }

  removeFromEnd() {
    if (!this.head) return null

    if (this.length === 1) {
      const value = this.head.value
      this.head = null
      this.tail = null
      this.length--
      return value
    }

    let current = this.head
    let previous = null

    while (current.next) {
      previous = current
      current = current.next
    }

    if (previous) {
      previous.next = null
      this.tail = previous
    }

    this.length--
    return current.value
  }

  toArray() {
    const array = []
    let current = this.head

    while (current) {
      array.push(current.value)
      current = current.next
    }

    return array
  }

  find(value: number) {
    if (!this.head) return -1

    let current = this.head
    let index = 0

    while (current) {
      if (current.value === value) {
        return index
      }
      current = current.next
      index++
    }

    return -1
  }
}

export default function LinkedListVisualizer() {
  const [linkedList, setLinkedList] = useState<LinkedList>(new LinkedList())
  const [newValue, setNewValue] = useState<string>("")
  const [searchValue, setSearchValue] = useState<string>("")
  const [searchIndex, setSearchIndex] = useState<number | null>(null)
  const [highlightIndices, setHighlightIndices] = useState<number[]>([])
  const [message, setMessage] = useState<string>("")
  const [listArray, setListArray] = useState<number[]>([])

  useEffect(() => {
    // Initialize with some values
    const initialList = new LinkedList()
    initialList.append(10)
    initialList.append(20)
    initialList.append(30)
    initialList.append(40)
    setLinkedList(initialList)
    setListArray(initialList.toArray())
  }, [])

  const resetHighlights = () => {
    setHighlightIndices([])
    setSearchIndex(null)
    setMessage("")
  }

  const handleAddToEnd = () => {
    if (!newValue.trim()) {
      toast({
        title: "Error",
        description: "Please enter a value",
        variant: "destructive",
      })
      return
    }

    const value = Number.parseInt(newValue)
    if (isNaN(value)) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive",
      })
      return
    }

    linkedList.append(value)
    setListArray(linkedList.toArray())
    setNewValue("")
    setHighlightIndices([linkedList.length - 1])
    setMessage(`Added ${value} at the end`)
  }

  const handleAddToStart = () => {
    if (!newValue.trim()) {
      toast({
        title: "Error",
        description: "Please enter a value",
        variant: "destructive",
      })
      return
    }

    const value = Number.parseInt(newValue)
    if (isNaN(value)) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive",
      })
      return
    }

    linkedList.prepend(value)
    setListArray(linkedList.toArray())
    setNewValue("")
    setHighlightIndices([0])
    setMessage(`Added ${value} at the beginning`)
  }

  const handleRemoveFromEnd = () => {
    if (linkedList.length === 0) {
      toast({
        title: "Error",
        description: "Linked list is empty",
        variant: "destructive",
      })
      return
    }

    const removed = linkedList.removeFromEnd()
    setListArray(linkedList.toArray())
    setMessage(`Removed ${removed} from the end`)
  }

  const handleRemoveFromStart = () => {
    if (linkedList.length === 0) {
      toast({
        title: "Error",
        description: "Linked list is empty",
        variant: "destructive",
      })
      return
    }

    const removed = linkedList.removeFromFront()
    setListArray(linkedList.toArray())
    setMessage(`Removed ${removed} from the beginning`)
  }

  const handleSearch = () => {
    if (!searchValue.trim()) {
      toast({
        title: "Error",
        description: "Please enter a search value",
        variant: "destructive",
      })
      return
    }

    const value = Number.parseInt(searchValue)
    if (isNaN(value)) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive",
      })
      return
    }

    const index = linkedList.find(value)
    setSearchIndex(index)

    if (index !== -1) {
      setHighlightIndices([index])
      setMessage(`Found ${value} at position ${index}`)
    } else {
      setHighlightIndices([])
      setMessage(`${value} not found in the linked list`)
    }
  }

  const handleReset = () => {
    const newList = new LinkedList()
    newList.append(10)
    newList.append(20)
    newList.append(30)
    newList.append(40)
    setLinkedList(newList)
    setListArray(newList.toArray())
    setNewValue("")
    setSearchValue("")
    resetHighlights()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center mb-4">
        {listArray.length === 0 ? (
          <div className="border border-dashed border-gray-300 rounded-md p-4 w-full text-center text-gray-500">
            Empty Linked List
          </div>
        ) : (
          <div className="flex flex-wrap items-center justify-center w-full">
            {listArray.map((value, index) => (
              <div key={index} className="flex items-center">
                <div
                  className={`flex flex-col items-center ${
                    highlightIndices.includes(index)
                      ? "bg-green-100 border-green-500"
                      : searchIndex === -1 && searchValue && Number.parseInt(searchValue) === value
                        ? "bg-red-100 border-red-500"
                        : "bg-white border-gray-300"
                  } border rounded-md p-4 min-w-[80px] transition-all duration-300`}
                >
                  <div className="text-xs text-gray-500 mb-1">
                    {index === 0 ? "head" : index === listArray.length - 1 ? "tail" : ""}
                  </div>
                  <div className="font-bold">{value}</div>
                </div>
                {index < listArray.length - 1 && (
                  <div className="px-2">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M5 12H19M19 12L12 5M19 12L12 19"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {message && <div className="bg-blue-50 border border-blue-200 rounded-md p-3 text-blue-800">{message}</div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="newValue">New Value</Label>
            <div className="flex space-x-2">
              <Input
                id="newValue"
                type="number"
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                placeholder="Enter a number"
              />
              <Button onClick={handleAddToEnd} size="icon">
                <PlusCircle className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex space-x-2">
            <Button onClick={handleAddToStart} className="flex-1">
              <ArrowRightFromLine className="mr-2 h-4 w-4" />
              Add to Start
            </Button>
            <Button onClick={handleAddToEnd} className="flex-1">
              Add to End
              <ArrowLeftFromLine className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <div className="flex space-x-2">
            <Button onClick={handleRemoveFromStart} variant="outline" className="flex-1">
              <MinusCircle className="mr-2 h-4 w-4" />
              Remove from Start
            </Button>
            <Button onClick={handleRemoveFromEnd} variant="outline" className="flex-1">
              Remove from End
              <MinusCircle className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="searchValue">Search Value</Label>
            <div className="flex space-x-2">
              <Input
                id="searchValue"
                type="number"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                placeholder="Enter a number to search"
              />
              <Button onClick={handleSearch} size="icon">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Button onClick={handleReset} variant="secondary" className="w-full">
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset Linked List
          </Button>
        </div>
      </div>

      <div className="bg-muted p-4 rounded-md">
        <h3 className="font-bold mb-2">Linked List Operations Time Complexity</h3>
        <ul className="space-y-1 text-sm">
          <li>
            <span className="font-medium">Access:</span> O(n) - Need to traverse from head
          </li>
          <li>
            <span className="font-medium">Search:</span> O(n) - Need to traverse from head
          </li>
          <li>
            <span className="font-medium">Insertion at beginning:</span> O(1) - Constant time
          </li>
          <li>
            <span className="font-medium">Insertion at end (with tail pointer):</span> O(1) - Constant time
          </li>
          <li>
            <span className="font-medium">Deletion at beginning:</span> O(1) - Constant time
          </li>
          <li>
            <span className="font-medium">Deletion at end:</span> O(n) - Need to find the node before tail
          </li>
        </ul>
      </div>
    </div>
  )
}

